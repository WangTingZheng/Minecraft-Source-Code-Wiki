This is an API used for handleing events across your java based projects.

It's meant to be simple to use without sacrificing performance and extensibility.

Currently the API is in beta fase, that means the API is stable but not done.
If you have any suggestions feel free to make a pull request or let me know on another way.